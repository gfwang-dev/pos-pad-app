CCangular.module('ipadPos.common', [])

.factory('common', function($ionicPopup, $timeout, $cordovaToast, $timeout, $rootScope, $http, $q, $ionicLoading,$cordovaSQLite,$ionicGesture,$timeout) {
	var Common = {};
	Common.ajaxE = function(data, status, headers, config) {
		$ionicLoading.hide();
		if (data != null && data.msg != null && data.msg != "") {
			try {
				Common.alert(data.msg);
				return;
			} catch (e) {
				console.log(e);
			}
		}
		if (!checkConnection()) {
			Common.alert("please check your internet connection.");
			return;
		}
		Common.alert("request error.");
	};

	Common.getAddress = function(){
		var ip =Common.getLocalData("ip");
		var baseUrl = "http://"+ip + "/";
		return baseUrl;
	}
	
	
	Common.post = function(url, data, errorBack) {
		var baseUrl = Common.getAddress()+"Meal.asmx/";
		var deferred = $q.defer();
		$http({
			method : 'POST',
			url :  baseUrl + url,
			data : data,
			headers : {
				'Content-Type' : 'application/x-www-form-urlencoded; charset=UTF-8'
			},
			transformRequest: function (data) {
			    　　return $.param(data||{});
			}
		}).success(function(result) {
			deferred.resolve(result);
		}).error(function(error) {
			deferred.reject(error);
		});
		/*
		 * $timeout(function() { console.log("链接超时..."); $ionicLoading.hide(); },
		 * 10000);
		 */
		return deferred.promise;
	};

	// 用户登陆
	Common.alert = function(title, subTitle) {
		// An elaborate, custom popup
		var myPopup = $ionicPopup.show({
			title : title,
			subTitle : subTitle
		});
		myPopup.then(function(res) {
			console.log('Tapped!', res);
		});
		$timeout(function() {
			myPopup.close(); // close the popup after 2.5 seconds for some
			// reason
		}, 2000);
		// $cordovaToast.showShortCenter(title);
	};

	
	Common.setWaiterPwd = function(scope,callBack,checkFc){
		var myPopup = Common.showModal(scope,"templates/pop/waiter-ctr.html");
		scope.setting = {};
		clickCloseModal(scope);
		scope.setting.success = function(){//点击确认
			if(!scope.setting.waiterPwd){//没有验证密码
				return;
			}
			checkFc(scope.setting.waiterPwd,function(res){
				if(res){
					myPopup.close();
					Common.addLocalData("waiterPwd",scope.setting.waiterPwd);
					callBack && callBack(true);
				}else{
					callBack && callBack(false);
				}
				
			});
		};
	};
	
	
	Common.setIp = function(scope,dbService,syndataService,callBack){
		var myPopup ;
		var _this = this;
		var setting = scope.setting = {};
		
		setting.success = function(){
			if(!!!setting.ip){
				
				return;
			}
			dbService.setSetting(setting,function(){
				myPopup.close();
				Common.addLocalData("ip",setting.ip);
				callBack && callBack(setting.ip);
			});
		};
		
		setting.synData = function(){
			syndataService.synData(function(res){
				//alert(res.msg);
			});
		};
		setting.setModel = Common.setModel;
		dbService.getSetting(function(res){
			setting.ip = res.ip;
			setting.isList = res.isList;
			setting.language = res.language;
			myPopup = _this.showModal(scope,"templates/pop/setip.html");
			//alert("myPopup:"+myPopup);
		});
		
		 
		 
	};
	
	
	Common.showSetting = function(scope,dbService,syndataService){
		var myPopup ;
		var _this = this;
		var setting = scope.setting = {};
		
		setting.success = function(){
			if(!!!setting.ip){
				return;
			}
			dbService.setSetting(setting,function(){
				myPopup.close();
				Common.addLocalData("ip",setting.ip);
				Common.alert("保存成功");
			});
		};
		
		setting.synData = function(){
			syndataService.synData(function(res){
				Common.alert("同步成功");
				//alert(res.msg);
			});
		};
		
		setting.setModel = Common.setModel;
		dbService.getSetting(function(res){
			//alert("返回结果:"+res);
			setting.ip = res.ip;
			setting.isList = res.isList;
			setting.language = res.language;
			
			myPopup = _this.showModal(scope,"templates/pop/setting.html");
			clickCloseModal(scope,myPopup);
		});
		
	};
	
	
	function clickCloseModal(scope,myPopup){
		/*
		 * scope.myPopup = scope.myPopup ||{}; scope.myPopup.isPopup = true; var
		 * eve; var $htmlEl= angular.element(document.querySelector('html'));
		 * eve = $ionicGesture.on("touch", function(event) { if
		 * (event.target.nodeName === "HTML" && scope.myPopup.isPopup) {
		 * myPopup.close(); $ionicGesture.off(eve,"touch") scope.myPopup.isPopup =
		 * false; } },$htmlEl);
		 */
	}
	
	
	
	Common.setModel = function(obj,key,val){
		if(!obj&&!key){
			return
		}
		obj[key] = val;
	};
	
	
	Common.showModal = function(scope,templateUrl,className){
		if(!scope){
			//alert("scope is empty");
			return "";
		}
		try{
		var myPopup = $ionicPopup.show({
			  cssClass:'setting-popup',	
			  templateUrl: templateUrl, // String (可选)。在弹窗body内的html模板的URL。
			  scope: scope, // Scope (可选)。一个链接到弹窗内容的scope（作用域）。
			});
		}catch(e){
			alert("窗口打开失败:"+JSON.stringify(e));
		}
		scope.pop_cancel = function(){
			myPopup.close();
		};
		return myPopup;
	}
	
	
	Common.getToken = function() {
		Common.getLocalData("token");
	}

	Common.getUserId = function() {
		Common.getLocalData("userId");
	}

	Common.isEmpty = function(value) {
		return angular.isUndefined(value) | value == '';
	};

	Common.isNotEmpty = function(value) {
		return (!angular.isUndefined(value)) && (value != '');
	};

	Common.addLocalData = function(key, value) {
		localStorage.setItem(key, value);
	};

	Common.addLocalJsonData = function(key, value) {
		localStorage.setItem(key, JSON.stringify(value));
	};

	Common.getLocalJsonData = function(key) {
		return JSON.parse(Common.getLocalData(key));
	};

	Common.removeLocalData = function(key) {
		localStorage.removeItem(key);
	};

	Common.getLocalData = function(key) {
		var res = localStorage.getItem(key);
		if (res == "null") {
			return "";
		}
		return res;
	};

	Common.clear = function() {
		localStorage.clear();
	};

	Common.downLoadImage = function(url,fileName,callBack,errorBack) {
		window.requestFileSystem = window.requestFileSystem || window.webkitRequestFileSystem;
		try{
		window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, function(fs) {
			console.log('打开的文件系统: ' + fs.name);
			// var url =
			// 'http://52.62.19.32:9999/goods/0CA5A338-2377-4B15-AD5A-AA091DEA8CF7.jpg';
			//alert('打开的文件系统: ' + fs.name);
			fs.root.getFile(fileName, {
				create : true,
				exclusive : false
			}, function(fileEntry) {
				Common.DownloadFile(fileEntry, url,callBack,errorBack);
			}, errorBack);

		}, errorBack);
		}catch(e){
			//alert("异常了:"+e.message);
			errorBack&&errorBack();
		}
	};

	Common.DownloadFile = function(fileEntry, url,callBack,errorBack) {
		var fileTransfer = new FileTransfer();
		var fileURL = fileEntry.toURL();
	
		
		fileTransfer.download(url, fileURL, function(entry) {

			callBack&&callBack( entry.toURL());
		},function(e){
			errorBack&&errorBack();
		}, null, // or, pass false
		{
		});
		
	};

	// 文件创建失败回调
	Common.onErrorCreateFile = function(error) {
		console.log("文件创建失败！")
	};

	// FileSystem加载失败回调
	Common.onErrorLoadFs = function(error) {
		console.log("文件系统加载失败！")
	};

	Common.loadImage = function() {
		window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, function(fs) {
			console.log('打开的文件系统: ' + fs.name);
			fs.root.getFile("hangge.png", {
				create : true,
				exclusive : false
			}, function(fileEntry) {
				var elem = document.getElementById('showImg');
				elem.src = fileEntry.toURL();
			}, Common.onErrorCreateFile);

		}, Common.onErrorLoadFs);
	};
	
	
	//showLoading动画加载
	Common.showLoading = function() {
		 $ionicLoading.show({
	         template: 'Loading...',
	         content: 'Loading',
	         animation: 'fade-in',
	         showBackdrop: true,
	         maxWidth: 200,
	         showDelay: 0
	       })
	}
	
	Common.hideLoading = function() {
		 $timeout(function () {
			 $ionicLoading.hide();
	        }, 200);	
	}
	
	
	//小数位不够，用0补足位数  
	Common.changeDecimalBuZero=function(number, bitNum) {//要处理的数字,生成的小数位数
        var f_x = parseFloat(number);  
        if (isNaN(f_x)) {  
            return 0;  
        }  
        var s_x = number.toString();  
        var pos_decimal = s_x.indexOf('.');  
        if (pos_decimal < 0) {  
            pos_decimal = s_x.length;  
            s_x += '.';  
        }  
        while (s_x.length <= pos_decimal + bitNum) {  
            s_x += '0';  
        }  
        return s_x;  
    }  
	
	return Common;
});

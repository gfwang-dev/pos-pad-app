'use strict';
angular.module('ipadPos.config', [])

.factory('config', function($cordovaSQLite) {
	var config = {};
	// 1 中文 ，2 英文，3中英文
	config.setting = {
		ip : '',
		isList : 1,
		language : 3
	};

	/**
	 * 餐桌状态枚举
	 */
	config.deskSate = {
		// 空闲
		CanUse : 0,
		// 正在消费
		OnUse : 1,
		// 已经预定
		Ording : 2,
		// 停用
		Stop : 3,
		// 未落单
		NoOverbooking : 4,
		// 清台中
		ClearIng : 5,
	}

	config.sysMsg = {
		success : function() {
			return {
				en : "syn success",
				cn : "同步成功",
				na : "syn success",
			};
		},
		imgSynFail : function() {
			return {
				en : "img syn fail",
				cn : "图片同步失败",
				na : "img syn fail",
			};
		},
		dataSynFail : function() {
			return {
				en : "data syn fail",
				cn : "商品同步失败",
				na : "data syn fail",
			}
		}
	}

	return config;
});
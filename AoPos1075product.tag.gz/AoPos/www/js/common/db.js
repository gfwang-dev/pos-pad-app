'use strict';
angular.module('ipadPos.db', [])

.factory(
		'db',
		function($cordovaSQLite, common, config) {
			var db, commonDb = {};
			var isClient = false;
			commonDb.dbName = {
				goods : "tbl_goods",
				area : "tbl_area",
				desk_info : "tbl_desk_info",
				goods_type : "tbl_goods_type",
				setting : "tbl_setting"
			};
			commonDb.initDb = function(callBack) {
				try {
					var u = navigator.userAgent;
					if (u.indexOf("Windows") == -1) {
						db = $cordovaSQLite.openDB({
							name : "ipadPos.db",
							location : 1
						});
					}

				} catch (e) {
					alert("初始化异常:" + JSON.stringify(e));
				}
				callBack && callBack();
			};

			commonDb.initSetting = function(callBack) {
				// alert("db:" + JSON.stringify(JSON.stringify(db)));
				if(!db){
				 callBack&&callBack();
				 return;
				 }
				var tbl_setting = "CREATE TABLE IF NOT EXISTS " + this.dbName.setting + " (db_id INTEGER PRIMARY KEY AUTOINCREMENT, " + "IP VARCHAR(50),isList TINYINT,language TINYINT)";
				execute(tbl_setting, [], callBack);
			};

			commonDb.initTable = function(syn, callBack) {
				// 商品信息表
				var tbl_goods = "CREATE TABLE IF NOT EXISTS " + this.dbName.goods + " (db_id INTEGER PRIMARY KEY AUTOINCREMENT, " + "IsNeedWeight INTEGER, " + "OrderIndex INTEGER," + "ObjectId VARCHAR(100)," + "ShopId INTEGER," + "Type VARCHAR(100)," + "Name VARCHAR(100)," + "NO VARCHAR(100),"
						+ "SmallintName VARCHAR(100)," + "Unit VARCHAR(100)," + "Cost INTEGER," + "Price DECIMAL(10,2)," + "MePrice DECIMAL(10,2)," + "Commission INTEGER," + "Count INTEGER," + "Discount TINYINT," + "DiscountNum INTEGER," + "OperateWay VARCHAR(100)," + "Nutrition VARCHAR(100),"
						+ "Other VARCHAR(100)," + "State TINYINT," + "UseAcount TINYINT," + "LastNumber INTEGER," + "Pic VARCHAR(100)," + "EnglishName VARCHAR(100));";

				// 餐厅分类表
				var tbl_area = "CREATE TABLE IF NOT EXISTS " + this.dbName.area + " (db_id INTEGER PRIMARY KEY AUTOINCREMENT, " + "ObjectId VARCHAR(100)," + "ShopId INTEGER," + "Name VARCHAR(100)," + "MinFee INTEGER," + "EnglishName VARCHAR(100));";

				// 菜品分类
				var tbl_good_type = "CREATE TABLE IF NOT EXISTS " + this.dbName.goods_type + " (db_id INTEGER PRIMARY KEY AUTOINCREMENT, " + "IsShow INTEGER," + "ObjectId VARCHAR(100)," + "ShopId INTEGER," + "Name VARCHAR(100)," + "PId VARCHAR(100)," + "EnglishName VARCHAR(100));";

				execute(tbl_goods, [], function() {
					execute(tbl_good_type, [], function() {
						execute(tbl_area, [], callBack);
					});
				});

				if (!db) {
					callBack && callBack();
				}
				console.log(tbl_goods);
				console.log(tbl_area);
				console.log(tbl_good_type);
			}

			function getCreateTableSql(fields, baseSql) {
				for (var i = 0; i < fields.length; i++) {
					if (i == fields.length - 1) {
						baseSql += fields[i] + ")";
					} else {
						baseSql += fields[i] + ",";
					}
				}
				return baseSql;
			}

			commonDb.batchInsert = function(dbName, list, fields, callBack) {
				var dle = "delete from " + dbName;
				common.addLocalJsonData(dbName, list);
				execute(dle, [], function() {	
					var arr=getAllList(list);
					insertLoop(arr,0,fields,callBack,dbName);
				});
				if (!db) {
					callBack && callBack();
				}

			};

			
			function insertLoop(arr,i,fields,callBack,dbName){
				if( i >= arr.length){
					callBack && callBack();
					return;
				}
				var res = getBatchInsertSql(dbName, arr[i], fields);
				execute(res.sql, res.val, function(){
					i++;
					insertLoop(arr,i,fields,callBack,dbName);
				});
			}
			
			
			
			function getAllList(list){
				if(!list||list.length<=0){
					return  [];
				}
				var pageSize = 10;
				var total = list.length;// 获取数据总共多少条
				var pages = total%pageSize>0?parseInt(total/pageSize)+1:total/pageSize;
				var arr=[];
			    for (var i = 0; i < pages; i++) {
			    	arr.push(list.slice(i*pageSize,i*pageSize+pageSize));
					}
			    return arr;
			}
			
			
			
			function getBatchInsertSql(tbName, list, fields) {
				var val = [];
				var sql = "INSERT INTO " + tbName + " (";
				for (var i = 0; i < fields.length; i++) {
					if (i == fields.length - 1) {
						sql += fields[i];
					} else {
						sql += fields[i] + ",";
					}
				}
				sql += ") VALUES ";

				for (var i = 0; i < list.length; i++) {
					sql += "(";
					for (var j = 0; j < fields.length; j++) {
						if (j == fields.length - 1) {
							sql += "?";
						} else {
							sql += "?,"
						}
						val.push(list[i][fields[j]]);
					}
					if (i == list.length - 1) {
						sql += ")";
					} else {
						sql += "),";
					}
				}
				var obj = {
					sql : sql,
					val : val
				};
				return obj;
			}

			commonDb.sysSetting = function(s, op, callBack) {
				s = s || {};
				var setting = {
					ip : s.ip,
					isList : s.isList,
					language : s.language
				};

				// if (!db) {
					if (op && op == 1) {
						var res = common.getLocalJsonData("setting");
						callBack && callBack(res);
					} else {
						common.addLocalJsonData("setting", setting);
						callBack && callBack(true);
					}
				// }

			};

			/**
			 * 获取餐厅类别
			 */
			commonDb.selectArealist = function(callback) {
				var sql = "SELECT * FROM  " + commonDb.dbName.area;
				execute(sql, [], callback);
				if (!db) {
					var list = common.getLocalJsonData(commonDb.dbName.area);
					var res = searchList(list);
					callback && callback(res);
				}
			};

			/**
			 * 根据区域id获取餐桌列表(用不着)
			 */
			commonDb.selectDeskByAreaId = function(areaId, callback) {
				var params = [ areaId ];
				var sql = "SELECT * FROM  " + commonDb.dbName.desk_info + " WHERE AreaID = ?";
				execute(sql, params, function(res) {
					callback && callback(res.rows);
				});
				if (!db) {
					var list = common.getLocalJsonData(commonDb.dbName.desk_info);
					var res = searchList(list, {
						AreaID : areaId
					});
					callback && callback(res);
				}
			};

			/**
			 * 获取菜谱分类
			 */
			commonDb.getGoodsType = function(callback) {
				var sql = "SELECT * FROM  " + commonDb.dbName.goods_type;
				// alert("开始查询:"+sql);
				execute(sql, [], function(res) {
					// alert(JSON.stringify(getDbResult(res)));
					callback && callback(getDbResult(res,true));
				});
				if (!db) {
					// alert("res"+JSON.stringify(res));
					var list = common.getLocalJsonData(commonDb.dbName.goods_type);
					var res = searchList(list);
					callback && callback(res);
				}
			};
				
			
			function getDbResult(res,show){
				var arr = [];
				for (var i = 0; i < res.rows.length; i++) {
					arr.push(res.rows.item(i));
				}
				return arr;
			}
			
			
			/**
			 * 根据类型id获取商品列表
			 */
			commonDb.getGoodsList = function(typeId, page, callback) {
				// var pageSize = 6;
				var params = [ typeId ];
				var sql = "SELECT * FROM  " + commonDb.dbName.goods + " WHERE Type = ? ";
				/*
				 * if (page >= 0) { sql += "limit ? offset ?";
				 * params.push(pageSize, page * pageSize); }
				 */
				execute(sql, params, function(res) {
					// alert(JSON.stringify(getDbResult(res)));
					callback && callback(getDbResult(res));
				});
				if (!db) {
					var list = common.getLocalJsonData(commonDb.dbName.goods);
					/*
					 * var res = searchList(list, { Type : typeId }, page,
					 * pageSize);
					 */
					var res = searchList(list, {
						Type : typeId
					});
					callback && callback(res);
				}
			}

			function execute(sql, params, callback) {
				if (db) {
					// alert("db start sql:" + sql);
					$cordovaSQLite.execute(db, sql, params || []).then(function(res) {
						// alert("db end:" + JSON.stringify(res));
						callback && callback(res);
					}, function(err) {
						callback && callback();
						alert("db error");
					});
				}
			}

			function searchList(list, params, page, pageSzie) {
				if (!params) {
					return list;
				}
				var arr = [];

				for (var i = 0; i < list.length; i++) {
					var sql = "";
					var obj = list[i];
					var isExist = true;
					for ( var key in params) {
						if (obj[key] != params[key]) {
							isExist = false;
							break;
						}
					}
					if (isExist) {
						arr.push(obj);
					}
				}
				var start = 0;
				var end = arr.length;
				if (page >= 0) {
					start = page * pageSzie;
					end = (page + 1) * pageSzie >= end ? end : (page + 1) * pageSzie;
				}
				var filterData = [];
				for (var i = start; i < end; i++) {
					var obj = arr[i];
					filterData.push(obj);
				}

				return filterData;
			}

			return commonDb;
		});
'use strict';

var app = angular.module('ipadPos');
app.factory('userService', function(common) {
	var user = {};
	var url = {
		login : "Login",
		userInfo : "GetUserByNameAndPW"
	};
	user.login = function(userName, pwd) {
		var data = {
			userName : userName,
			psw : pwd
		}
		return common.post(url.login, data);
	};

	user.getLoginUserInfo = function(userName, pwd) {
		var data = {
			userName : userName,
			psw : pwd
		}
		return common.post(url.userInfo, data);
	};

	return user;

});
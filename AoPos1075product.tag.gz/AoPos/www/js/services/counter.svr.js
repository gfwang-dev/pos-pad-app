'use strict';

var app = angular.module('ipadPos');
app.factory('counterService', function(common,$http) {
	var counter = {};
	var url = {
			getAreaList : "GetAreaList",
			getDeskInfoListByAreaID:"GetDeskInfoListByAreaID",
			getDeskState:"GetDeskState",
			startBill:"StartBill",
			addFood:"AddFood",
			orderPayRecordInfo:"OrderPayRecordInfo",
			cancelBackGoods:"CancelBackGoods",
			getPayRecordInfoListByPayRecordID:"GetPayRecordInfoListByPayRecordID",
			validateCode:"ValidateCode"
			
		};

	// 获得所有区域
	counter.getAreaList = function() {
		var data = {}
		return common.post(url.getAreaList, data);
	};
	
	//根据区域id获取餐台
	/*counter.getDeskInfoListByAreaID=function(areaId){
		var data={
				areaId:areaId
		}
		return common.post(url.getDeskInfoListByAreaID, data);
	}*/
	
	//根据餐桌ID获得该餐桌状态 
	counter.getDeskState=function(deskId){
		var data={
				deskId:deskId		
		}
		return common.post(url.getDeskState, data);
	}
	
	//开台
	counter.startBill=function(type,deskObjectID,waiter,personSize,otherMsg){
		var data={
				type:type,
				deskObjectID:deskObjectID,
				waiter:waiter,
				personSize:personSize,
				otherMsg:otherMsg
		}
		return common.post(url.startBill, data);
	}
	
 //点菜
	counter.addFood=function(goodObjectID,deskObjectID,waiter,number,orderMark){
		  var data={
				  goodObjectID:goodObjectID,
				  deskObjectID:deskObjectID,
				  waiter:waiter,
				  number:number,
				  orderMark:orderMark
		  }
		  return common.post(url.addFood, data);
	}
	
  //下单
	counter.orderPayRecordInfo=function(deskObjectID,orderType,waiter){
		 var  data={
				 deskObjectID:deskObjectID,
				 orderType:orderType,
				 waiter:waiter
		 }
		 return common.post(url.orderPayRecordInfo, data);
	}
	
	/*counter.orderPayRecordInfo=function(deskObjectID,orderType,waiter){
		var baseUrl = common.getAddress()+"Meal.asmx/OrderPayRecordInfo";
		return $http({
			method : "POST",
			cache:false,
			url : baseUrl,
			data : {
				deskObjectID : deskObjectID,
				orderType:orderType,
				waiter:waiter
			},
			headers : {
				'Content-Type' : 'application/x-www-form-urlencoded;charset=utf-8', 
			},
			transformRequest: function (data) {
			    　　return $.param(data);
			}
		});
	}*/
	
	
	//退菜
	counter.cancelBackGoods=function(deskObjectID,paycordObjectID,number,waiter){
		var data={
				deskObjectID:deskObjectID,
				paycordObjectID:paycordObjectID,
				number:number,
				waiter:waiter
		}
		 return common.post(url.cancelBackGoods, data);
	}
	
	//根据消费id查看这桌的总共菜肴
	counter.getPayRecordInfoListByPayRecordID=function(payRecordID){
		var data={
				payRecordID:payRecordID	
		}
		 return common.post(url.getPayRecordInfoListByPayRecordID,data);
	}
	
	//测试服务员code是否正确
	counter.validateCode =function(code){
		var data={
				code:code
		}
		return common.post(url.validateCode,data);
	}
	
	return counter;

});
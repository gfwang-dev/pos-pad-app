'use strict';

var app = angular.module('ipadPos');
app.factory('myMenuService', function(common) {
	
});
'use strict';

function syndataService(common, db, config) {
	var syn = {
		goods : [],
		goods_fields : [],
		goods_type : [],
		goods_type_fields : [],
		area : [],
		area_fields : [],
		desk : [],
		desk_fields : []
	};

	function getMsg(code, key) {
		return {
			code : code || 0,
			msg : config.sysMsg[key]().na
		}
	}

	syn.synData = function(fc) {
		synGodds(function() {
			db.initTable(syn, function() {
				db.batchInsert(db.dbName.goods, syn.goods, syn.goods_fields, function() {
					db.batchInsert(db.dbName.goods_type, syn.goods_type, syn.goods_type_fields, function() {
						fc && fc(getMsg(0, 'success'));
					});
				});
			});

		});
	};

	function synGodds(callBack) {
		common.post("GetAllGoods").then(function(res) {
			console.log("全部商品信息：");
			console.log(res);
			try {
				loadGoodsImg(res, 0, function(obj) {
					synGoddsType(callBack);
					if (res.length > 0) {
						syn.goods_fields = getFileds(res[0]);
					}
					syn.goods = res;
				});
			} catch (e) {
				//alert(e.message);
			}

		});
	}

	function loadGoodsImg(res, i, callBack) {
		if (i >= res.length) {
			callBack && callBack(res);
			return;
		}
		var obj = res[i];
		if (obj.Pic) {
			obj.Pic = common.getAddress() + "goods/" + obj.Pic;
		} else {
			i++;
			loadGoodsImg(res, i, callBack);
			return;
		}
		var index = obj.Pic.lastIndexOf("/");
		var name = obj.Pic.substring(index + 1);
		common.downLoadImage(obj.Pic, name, function(pic) {
			obj.Pic = pic;
			i++;
			loadGoodsImg(res, i, callBack);
		}, function() {
			obj.Pic = "";
			i++;
			loadGoodsImg(res, i, callBack);
		});
	}

	function synGoddsType(callBack) {
		common.post("GetGoodsType").then(function(res) {
			console.log("全部商品类型:");
			console.log(res);
			synArea(callBack);
			if (res.length > 0) {
				syn.goods_type_fields = getFileds(res[0]);
			}
			syn.goods_type = res;
		});
	}

	function synArea(callBack) {
		common.post("GetAreaList").then(function(res) {
			console.log("全部区域:");
			console.log(res);
			if (res.length > 0) {
				syn.area_fields = getFileds(res[0]);
			}
			syn.area = res;
			var desk = [];
			callBack && callBack();
			if (!res || res.length <= 0) {
				return;
			}

			/*
			 * synDeskByAreaId(res, 0, desk, function(obj) { syn.desk = desk;
			 * callBack && callBack(); });
			 */
		});
	}

	function synDeskByAreaId(area, i, arr, callBack) {
		if (i >= area.length) {
			// 加载完成
			callBack && callBack();
			return;
		}
		common.post("GetDeskInfoListByAreaID", {
			areaId : area[i].ObjectId
		}).then(function(res) {
			console.log("区域" + area[i].ObjectId + "中的餐桌:");
			console.log(res);
			arr.concat(res);
			if (i == 0) {
				syn.desk_fields = getFileds(res[0]);
			}
			i++;
			synDeskByAreaId(area, i, arr, callBack);
		});
	}

	function getFileds(obj) {
		var fileds = [];
		for ( var key in obj) {
			fileds.push(key);
		}
		return fileds;
	}

	return syn;
}

angular.module('ipadPos').factory('syndataService', [ 'common', 'db', 'config', syndataService ]);
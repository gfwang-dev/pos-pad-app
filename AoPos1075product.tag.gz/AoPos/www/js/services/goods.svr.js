'use strict';

var app = angular.module('ipadPos');
app.factory('goodService', function(common) {
	var goods = {};
	var desk = common.getLocalJsonData("currentDesk");

	goods.addFood = function(goodId,deskId, waiterPwd, number, orderMark) {
		return common.post("AddFood", {
			goodObjectID : goodId,
			deskObjectID : deskId,
			waiter : waiterPwd,
			number : number,
			orderMark : orderMark
		});

	};

	// 根据消费id查看这桌的总共菜肴
	goods.getMyGoods = function(payRecordID) {
		var data = {
		   payRecordID : payRecordID
		}
		return common.post("GetPayRecordInfoListByPayRecordID", data);
	}
	
	
	//退菜
	goods.cancelBackGoods=function(deskObjectID,paycordObjectID,number,waiter){
		var data={
				deskObjectID:deskObjectID,
				paycordObjectID:paycordObjectID,
				number:number,
				waiter:waiter
		}
		 return common.post("CancelBackGoods", data);
	}
	
	//获取商品分类
	goods.getGoodsType=function(){
		var data={};
		return common.post("GetGoodsType", data);
	}
	
	
	return goods;
});
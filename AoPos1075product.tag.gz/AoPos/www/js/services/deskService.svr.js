'use strict';

var app = angular.module('ipadPos');
app.factory('deskService', function(common, db) {
	var desk = {};
	
	//根据区域id获取所有餐桌
	desk.getList = function(areaId) {
		return common.post("GetDeskInfoListByAreaID", {
			areaId : areaId,
		});
	};

	return desk;
});
'use strict';

var app = angular.module('ipadPos');
app.factory('dbService', function(common, db, config) {
	var data = {};

	data.getAreaList = function(callback) {
		db.selectArealist(callback);
	};

	data.getGoodsTypeList = function(callback) {
		db.getGoodsType(callback);
	};

	data.getSetting = function(callBack) {
		db.sysSetting(config.setting, 1, function(res) {
			if (!res) {
				callBack && callBack(config.setting);
			} else {
				callBack && callBack(res);
			}

		});
	};

	data.getGoodsList = function(typeId, page, callback) {
		db.getGoodsList(typeId, page, function(res) {
			callback && callback(res);
		});
	}

	data.setSetting = function(obj, callBack) {
		db.sysSetting(obj||config.setting, "", function(res) {
			callBack && callBack(res);
		});
	};

	data.checkWaiterPwd = function(code, fc) {
		return common.post("ValidateCode", {
			code : code
		}).then(function(res) {
			fc && fc(res.Code);
		});
	};

	return data;
});
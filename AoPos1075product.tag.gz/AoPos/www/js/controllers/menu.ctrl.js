'use strict';

function menuController($scope, syndataService, dbService, common, $ionicScrollDelegate,$ionicSlideBoxDelegate,$state,goodService) {
	var fc = $scope.fc = {};
	var currentDesk =$scope.currentDesk = common.getLocalJsonData("currentDesk");
	var footer_c = $scope.footer_c = {menu:"menu-active"};
	var commonSet = $scope.commonSet = common.getLocalJsonData("setting");
	var data = $scope.data = {
			goodsList :[],
			myGoodsList :[],
			goodsDetailList :[],
	};
	var list_param = $scope.list_param = {
		page : 0,
		isLoad : false,
		typeId : "",
		hasData : true,
		size : function() {
			return window.screen.width * (this.page-1);
		},
		currentPage:0,
		currentGood:{},
		isDetail:(commonSet.isList==2),
		currentDetail: 0,
	};
	loadList();
	

	// 获取菜品分类
	function loadList() {
		getMyGoods(function(){
			dbService.getGoodsTypeList(function(list) {
				// alert("菜品种类有："+JSON.stringify(list));
				data.typeList = list;
				$scope.goodWidth=100/list.length;
				if (!list) {
					return;
				}
				list_param.typeId = list[0].ObjectId;
				getGoodsList();
			});
		});
	}
	
	
	// 获取菜品列表
	function getGoodsList(callBack) {
		dbService.getGoodsList(list_param.typeId, list_param.page, function(res) {
			 data.goodsList = goodsPage(res);
		     data.goodsDetailList = res;
		     setGoodsStatus();
			 list_param.currentDetail = 0;
			 list_param.currentPage=0; 
			 $ionicSlideBoxDelegate.$getByHandle('goods-box').update();
			 $ionicSlideBoxDelegate.$getByHandle('goods-detail-box').update();
			 callBack&&callBack();
		});
	}

    function goodsPage(list){
    	var total = list.length;
    	var pages = total%6>0?parseInt(total/6)+1:total/6;
    	var arr = [];
    	for (var i = 0; i < pages; i++) {
    		arr.push(list.slice(i*6,i*6+6));
		}
    	return arr;
    }
	
	
	
	function getMyGoods(callBack){
		  if(!currentDesk||!currentDesk.PayRecordId){ 
			  callBack && callBack({});
		  return; 
		  }
		 goodService.getMyGoods(currentDesk.PayRecordId).then(function(list){ // 根据消费id获取我的菜单
			 data.myGoodsList = list;
			callBack&&callBack(list);
		});
	}
	
	
	function setGoodsStatus(){
		for (var i = 0; i <data.goodsDetailList.length; i++) {
			var good = data.goodsDetailList[i];
			good.myGood = {};
			good.isAdd = false;	
			for (var j = 0; j < data.myGoodsList.length; j++) {
				var myGood = data.myGoodsList[j];
				if(myGood.State == 0 && good.ObjectId == myGood.GoodsObjectID){
					good.myGood = myGood;
					good.isAdd = true;
					break;
				}
			 }
		}
		$ionicSlideBoxDelegate.$getByHandle('goods-box').update();
		$ionicSlideBoxDelegate.$getByHandle('goods-detail-box').update();
	}
	
	
	fc.addFood = function(goods){
		 var deskId = currentDesk.ObjectId;
		// 判断有没有桌子id，没有桌子id进行return
		 if(!deskId){
			 return;
		 }
		 
		common.showLoading();// 动画加载
		var waiterPwd = common.getLocalData("waiterPwd");
		var goodsId = goods.ObjectId;
		var isAdd = goods.isAdd;
		var number = 1;
		var orderMark = "";
	    var payRecordId = currentDesk.PayRecordId;
	   
		if(!isAdd){
			goodService.addFood(goodsId,deskId, waiterPwd, number, orderMark).then(function(re){
				common.hideLoading();// 动画消失
				if(re.Code){
					getMyGoods(setGoodsStatus)
					// getGoodsList();
				}else{
					common.alert("提示",re.Msg);
				}
				});
		}else{
			goodService.cancelBackGoods(deskId,goods.myGood.ObjectId,goods.myGood.Number,waiterPwd).then(function(re){
				common.hideLoading();// 动画消失
				if(re.Code){
					getMyGoods(setGoodsStatus)
				}else{
					common.alert("提示",re.Msg);
				}
			});
		}
		
	};
	
		
	fc.waiterOp = function(){
		common.setWaiterPwd($scope,function(res){
			if(!res){
				common.alert("提示","服务员验证码错误");
				
			}else{
				$state.go("pos.counter");
			}
		},dbService.checkWaiterPwd);
	};
	
	// goods-detail-box
	// $ionicSlideBoxDelegate.$getByHandle('goods-detail-box').update();
	fc.scrollx = function(e) {
		
		 var scroll = $ionicSlideBoxDelegate.$getByHandle('goods-box')
		 var index = scroll.currentIndex(); 
		 list_param.currentPage=index; 
	};
	
	fc.scrollDetailx = function(){
		 var scroll = $ionicSlideBoxDelegate.$getByHandle('goods-box')
		 var index = scroll.currentIndex(); 
		 list_param.currentPage=index; 
	};
	

	fc.getAreaList = function() {
		dbService.getAreaList(function(res) {
			console.log(res);
		});
	};

	fc.showSetting = function() {
		common.showSetting($scope, dbService, syndataService);
	};

	fc.setModel = function(obj,key,val){
		if(!obj&&!key){
			return
		}
		var old = obj[key];
		obj[key] = val;
		if(key=="typeId"&&old!=obj[key]){
			list_param.page = 0;
			data.goodsList = [];
			data.goodsDetailList = [];
			getGoodsList();
		}
	};
	
	fc.goDetail = function(good,p,i){
		good.parentIndex = p;
		good.index = i;
		list_param.currentGood = good;
		list_param.isDetail=true;
		list_param.currentDetail = p*6+i;
		$ionicSlideBoxDelegate.$getByHandle('goods-detail-box').update();
	}

    // 上一个
	fc.prevDetail = function(){		
		var parentIndex = list_param.currentGood.parentIndex;// 分页的index
		var index=  list_param.currentGood.index;// 每个菜品的index
		var arr = data.goodsList[parentIndex];
		if(index>0){
			index--;
		}else{
			if(parentIndex>0){
				parentIndex--;
				index = data.goodsList[parentIndex].length-1;
			}else{// 第一个
				// $scope.prev=false;
				return;
			}
		}
		list_param.currentGood = data.goodsList[parentIndex][index];
		list_param.currentGood.parentIndex = parentIndex;
		list_param.currentGood.index = index;
		list_param.currentDetail = parentIndex*6+index;
		$ionicSlideBoxDelegate.$getByHandle('goods-detail-box').update();
		console.log("prev:"+list_param.currentDetail);
	};
	
	// 下一个
	fc.nextDetail = function(){
		var parentIndex = list_param.currentGood.parentIndex;
		var index =  list_param.currentGood.index;// 菜的index
		var arr = data.goodsList[list_param.currentGood.parentIndex];// 每页的6个菜品
		if(index<arr.length-1){// 菜品的index小于每一页菜品数量-1
			index++;
			list_param.currentGood = data.goodsList[parentIndex][index];
			list_param.currentGood.parentIndex = parentIndex;
			list_param.currentGood.index = index;
			list_param.currentDetail = parentIndex*6+index;
			$ionicSlideBoxDelegate.$getByHandle('goods-detail-box').update();
			console.log("next:"+list_param.currentDetail);
		}else{
			if((data.goodsList.length-1)>parentIndex){// 分页的index小于分页总数-1
				parentIndex++;
				index = 0;
				list_param.currentGood = data.goodsList[parentIndex][index];
				list_param.currentGood.parentIndex = parentIndex;
				list_param.currentGood.index = index;
				list_param.currentDetail = parentIndex*6+index;
				$ionicSlideBoxDelegate.$getByHandle('goods-detail-box').update();
				console.log("next:"+list_param.currentDetail);
			}else{// 最后一个
				// $scope.next=false;
			}
		}
	};
	
	fc.goMenu = function(){
		list_param.isDetail=false;
	};

}

angular.module('ipadPos').controller('menuController', menuController);
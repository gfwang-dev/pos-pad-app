'use strict';

function settingController($scope, syndataService, dbService) {
	var setting = {};
	var ip = common.getLocalData("ip");
	if (!ip || ip == "null") {
		common.showModal($scope, "templates/pop/setting.html");
	}
}

angular.module('ipadPos').controller('settingController', settingController);

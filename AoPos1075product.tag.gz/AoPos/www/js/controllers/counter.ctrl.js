'use strict';

function counterController($scope, $state, counterService, deskService, config, dbService, syndataService, common, $ionicSlideBoxDelegate,$ionicLoading) {
	var data = $scope.data = {};
	var bounced;// 弹框
	$scope.type = 0;// 0是堂吃,1是外卖
	$scope.areaId;// 区域id
	$scope.waiter = common.getLocalData("waiterPwd");
	$scope.personSize={
		num:""
	}
	// 获取areaId
	getArealist();
	/*function getArealist() {
		dbService.getAreaList(function(res) {
			console.log(res);
			if (res) {
				data.areaList = res;
				//res[0].active = "active";
				$scope.areaIndex=res.length;
				$scope.areaWidth=100/res.length;
				for (var i = 0; i < res.length; i++) {
					common.addLocalData("area" + [ i ], res[i].ObjectId);
				}
				$scope.areaId = common.getLocalData("area0");// 包厢
				getList($scope.areaId);// 默认显示包厢页面

			}
		});
	};*/
	function getArealist() {
		counterService.getAreaList().then(function(res) {
			console.log(res);
			if (res) {
				data.areaList = res;
				//res[0].active = "active";
				$scope.areaIndex=res.length;
				$scope.areaWidth=100/res.length;
				for (var i = 0; i < res.length; i++) {
					common.addLocalData("area" + [ i ], res[i].ObjectId);
				}
				$scope.areaId = common.getLocalData("area0");// 包厢
				getList($scope.areaId);// 默认显示包厢页面

			}
		});
	};
	
	
	
	// 根据区域id获取餐桌
	function getList(areaId) {
		common.showLoading();//动画加载
		deskService.getList(areaId).then(function(res) {
			console.log(res);
			$scope.deskList = res;
			for (var i = 0; i < res.length; i++) {
				if (res[i].State == config.deskSate.CanUse) {// 空
					res[i].stateColor = "ion kong";
					res[i].stateWord = "空";
				} else if (res[i].State == config.deskSate.OnUse) {// 吃
					res[i].stateColor = "ion chi";
					res[i].stateWord = "吃";
				} else if (res[i].State == config.deskSate.Stop) {// 停
					res[i].stateColor = "ion ting";
					res[i].stateWord = "停";
				} else if (res[i].State == config.deskSate.NoOverbooking) {// 点
					res[i].stateColor = "ion dian";
					res[i].stateWord = "点";
				}else{
					res[i].stateColor = "ion wu";
					res[i].stateWord = "无";
				}
			}
		common.hideLoading();//动画消失
		});
	}

	// 根据餐桌ID获得该餐桌状态
	$scope.getDeskState = function(obj) {// 点击餐桌
		counterService.getDeskState(obj.ObjectId).then(function(res) {
			console.log(res);
			if (config.deskSate.CanUse == res) {//空
				$scope.personSize.num="";//点餐人数置空
				//$scope.currentDesk = obj;
				//common.addLocalJsonData("currentDesk", obj);// 将该桌返回的所有信息全部存进本地缓存
				$scope.deskId = obj.ObjectId;// 传到页面上显示
				$scope.num = obj.DeskNo;
				bounced = common.showModal($scope, "templates/pop/counter-kaitai.html");
			} else if (config.deskSate.Stop == res) {//停用
				common.alert("提示", "该桌已停用");
			} else {//吃和点
				common.addLocalJsonData("currentDesk", obj);// 将该桌返回的所有信息全部存进本地缓存
				$state.go("pos.menu");
			}
		})
	}

	// 开台
	$scope.startBill = function(res) {//,currentDesk
		var personSize=res.num;
		var otherMsg = ""; 
        	if (personSize > 0) {// 用餐人数大于0
    			bounced.close();
    			counterService.startBill($scope.type, $scope.deskId, $scope.waiter, personSize, otherMsg)
    			.then(function(res) {
    				console.log(res);
    				if (res.Code) {
    					common.alert("开台", "开台成功");
    					var currentDesk = res.Msg;
    					//currentDesk.PayRecordId = res.Msg.PayRecordId;//将currentDesk里面的PayRecordId替换成返回过来的id。原始的PayRecordId为'00000000-0000-0000-0000-000000000000'
    					//currentDesk.ObjectId = res.Msg.ObjectId;
    					//currentDesk.DeskNo = res.Msg.DeskNo;
    					common.addLocalJsonData("currentDesk",currentDesk);
    					$state.go("pos.menu");
    				} else {
    					common.alert("开台", "开台失败");
    				}
    			})
    		} else {
    			common.alert("人数", "用餐人数不能少于1人");
    		}		
	}

	
	
	
	
	// 刷新和页面跳转
	$scope.jump = function(areaId) {
		$scope.personSize.num="";//点餐人数置空
	     $scope.areaId=areaId;
	     var areaIndex= "area"+($scope.areaIndex-1);
		var wmId = common.getLocalData(areaIndex);
		if (wmId == areaId) {
			$scope.type = 1;// 开台时传的type,1表示外卖;页面显示(ng-if)
			getTakeOutList(areaId);
					
		} else {
			$scope.type = 0;
		   getList(areaId);
		}
	}

	// 外卖
	// 根据区域id获取餐桌
	function getTakeOutList(areaId) {
		common.showLoading();//动画加载
		deskService.getList(areaId).then(function(res) {
			console.log(res);
			$scope.takeOutList = res;
			for (var i = 0; i < res.length; i++) {
				if (res[i].State == config.deskSate.OnUse) {// 等待返回1
					res[i].stateColor = "ion chi";
					res[i].stateWord = "等";
				} else if (res[i].State == config.deskSate.NoOverbooking) {// 点菜返回4 CanUse
					res[i].stateColor = "ion dian";
					res[i].stateWord = "点";
				}else{
					res[i].stateColor = "ion wu";
					res[i].stateWord = "无";
				}
			}
		common.hideLoading();//动画消失
		});
	}

	// 开外卖提示框
	$scope.getTakeOut = function() {
		$scope.personSize.num="";//点餐人数置空
		$scope.currentDesk={};
		bounced = common.showModal($scope, "templates/pop/counter-kaitai.html");
	};

	// 点击餐桌
	$scope.getTakeOutMessage = function(obj) {
		$scope.currentDesk = obj;
		common.addLocalJsonData("currentDesk", $scope.currentDesk);// 将该桌返回的所有信息全部存进本地缓存
		$state.go("pos.menu");
	}

	// 底边菜单栏
	// 设置
	$scope.openSet = function() {
		common.showSetting($scope, dbService, syndataService);
	}
	
	//人数的判断
	 $scope.zhengshu=function(personSize,num){
		 personSize[num] =personSize[num].replace(/[^0-9]/ig, "");// 不能填小数点
			var strlength=personSize[num].length;
			if(strlength>3){
				personSize[num]=personSize[num].substring(0, 3);
			}
	 }
	 
	
}

var app = angular.module('ipadPos');

app.controller('counterController', counterController);

app.filter("cut",function(){
	return function(value,wordwise,max,tail){
		if (!value) return '';

		max = parseInt(max, 10);
		if (!max) return value;
		if (value.length <= max) return value;

		value = value.substr(0, max);
		if (wordwise) {
		var lastspace = value.lastIndexOf('');
		if (lastspace != -1) {
		value = value.substr(0, lastspace);
		}
		}
		return value + (tail || '...');
	}
});
'use strict';

function testController($scope, syndataService, dbService) {
	var fc = $scope.fc = {};

	fc.synMenu = function() {
		syndataService.synData(function() {
			console.log("syn start");

			console.log(syndataService.desk_fields);

			console.log("syn end")
		});
	};

	fc.getAreaList = function() {
		 dbService.getAreaList(function(res) {
			console.log(res);
		});
	};
}

angular.module('ipadPos').controller('testController', testController);
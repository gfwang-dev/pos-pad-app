'use strict';

function myMenuController($scope, $state, counterService, deskService, config, dbService, syndataService, common,$timeout) {
	var fc = $scope.fc = {};
	var footer_c = $scope.footer_c = {my_menu:"menu-active"};
	$scope.waiter=common.getLocalData("waiterPwd");//获取密码
	 var currentDesk =$scope.currentDesk = common.getLocalJsonData("currentDesk")||{};
	 $scope.payRecordID=currentDesk.PayRecordId;//消费id
	 $scope.deskObjectID=currentDesk.ObjectId;//获取桌子id
    // 根据消费id查看这桌的总共菜肴
	 getPayRecordInfoListByPayRecordID();
	 function getPayRecordInfoListByPayRecordID(){
	counterService.getPayRecordInfoListByPayRecordID($scope.payRecordID).then(function(res) {
		console.log(res);
		$scope.goodList = res;
		$scope.allPrice=0;//总价
		for (var i = 0; i < res.length; i++) {
		res[i].Price=common.changeDecimalBuZero(res[i].Price,2);//价格
		
		var xiaoji=res[i].Number*res[i].Price;//计算的小计
		res[i].xiaoji=common.changeDecimalBuZero(xiaoji,2);//显示的小计
		
		$scope.allPrice=$scope.allPrice+xiaoji;//计算的总价
		
		if(res[i].State==0){
			res[i].goodState="未下单";
		}else{
			res[i].goodState="已下单";
		}
		/*else if(res[i].State==1){
			res[i].goodState="已下单";
		}
		else if(res[i].State==2){
			res[i].goodState="已做好";
		}
		else if(res[i].State==3){
			res[i].goodState="已退菜";
		}*/
		}
		$scope.allPrice=common.changeDecimalBuZero($scope.allPrice,2);//显示的总价
		common.hideLoading();//动画消失
	})
	 }
	
    // 落单按钮
	$scope.placeOrder = function() {
		//判断菜品的状态，如果状态为0未下单状态，可以点击落单。如果为1已下单状态，不可点击落单
		var judge=false;
		for (var i = 0; i < $scope.goodList.length; i++) {
			var state=$scope.goodList[i].State;
			if(state==0){
				judge=true;
			}
		}
		if(judge){//有未下单的菜
		common.setWaiterPwd($scope,function(res){
			if(!res){
				common.alert("提示", "服务员输入密码错误");
			}else{
				orderPayRecordInfo($scope.waiter);
			}
		},dbService.checkWaiterPwd);//传的参数：作用域，落单事件，验证code
		}else{//全部为已下单的菜
			common.alert("提示", "没有未下单的菜");
			}
	}
	

	// 落单
	function orderPayRecordInfo(waiter) {
		var orderType = 0;// 0默认,1已下单,2已做好,3已退菜	
		counterService.orderPayRecordInfo($scope.deskObjectID, orderType,waiter).then(function(res) {
			console.log(res);
			if (res.Code) {// 落单成功
				/*$timeout(function () {
					getPayRecordInfoListByPayRecordID();
					common.alert("提示", "落单成功");
			        }, 5000);	*/	
				getPayRecordInfoListByPayRecordID();
				common.alert("提示", "落单成功");
			} else {
				common.alert("提示", "落单失败");
			}
		})
	}

	// 加菜
	$scope.addFood = function(goodObjectID, OrderMark) {
		counterService.addFood(goodObjectID, $scope.deskObjectID,$scope.waiter,1,OrderMark).then(function(res) {
			console.log(res);
			if(res.Code){
				//$state.reload();//刷新页面
				getPayRecordInfoListByPayRecordID();
			}else{
				common.alert("提示",res.Msg);
			}
		})
	}


	// 退菜(deskObjectID传过来的)
	$scope.cancelBackGoods = function(goodObjectID,payRecordID,state) {
		if(state==0){
			cancelGoods($scope.deskObjectID,payRecordID,$scope.waiter);
		}else{
		common.setWaiterPwd($scope,function(res){
			if(!res){
				common.alert("提示", "服务员输入密码错误");
			}else{
				cancelGoods($scope.deskObjectID,payRecordID,$scope.waiter);
			}
		},dbService.checkWaiterPwd);//传的参数：作用域，落单事件，验证code
		}
	}
	
	function cancelGoods(deskObjectID,payRecordID,waiter){
		counterService.cancelBackGoods(deskObjectID,payRecordID, 1,waiter).then(function(res) {
			console.log(res);
			if(res.Code){
				//$state.reload();//刷新页面
				getPayRecordInfoListByPayRecordID();
			}else{
				common.alert("提示",res.Msg);
			}
		})
	}
	
	

	//刷新
	$scope.refresh = function() {
		 common.showLoading();//动画加载
		 getPayRecordInfoListByPayRecordID();
	}
	

	fc.waiterOp = function() {
		common.setWaiterPwd($scope, function(res) {
			if (!res) {
				alert("服务员验证码错误");
			} else {
				$state.go("pos.counter");
			}
		}, dbService.checkWaiterPwd);
	};
	
	fc.goMenu = function(){
		$state.go("pos.menu");
	};
}

var app = angular.module('ipadPos');

app.controller('myMenuController', myMenuController);
app.directive('scrollHeight',function($window){
	  return{
	    restrict:'AE',
	    link:function(scope,element,attr){
	      element[0].style.height=($window.innerHeight-80-75)+'px';
	    }
	  }
	})
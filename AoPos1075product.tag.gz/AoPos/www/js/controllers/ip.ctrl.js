'use strict';

function ipController($scope, $state, $rootScope, common) {
	var fc = $scope.fc = {};
	var pos = $scope.pos = {};
	fc.next = function() {
		if (!!!pos.ip || !!!pos.port) {
			return;
		}
		$rootScope.rootUrl = "http://" + pos.ip + ":" + pos.port + "/Meal.asmx";
		common.addLocalData("ip",$rootScope.rootUrl);
		$state.go("login");
	};
}

var app = angular.module('ipadPos');

app.controller('ipController', ipController);
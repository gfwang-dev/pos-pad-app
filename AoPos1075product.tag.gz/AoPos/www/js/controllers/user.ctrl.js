'use strict';

function userController($scope, $state, $rootScope, userService, common) {
	var user = $scope.user = {};
	var fc = $scope.fc = {};

	fc.login = function() {
		if (!user.ip) {
			return;
		}
		$rootScope.rootUrl = "http://" + user.ip + "/Meal.asmx";
		common.addLocalData("ip", $rootScope.rootUrl);
		$state.go("test");

		/*
		 * userService.login(user.userName, user.psw).then(function(res) { if
		 * (res && res.Code) { common.addLocalData("ip", $rootScope.rootUrl);
		 * common.addLocalData("userName", user.userName);
		 * common.addLocalData("pwd", user.psw);
		 * userService.getLoginUserInfo(user.userName,
		 * user.psw).then(function(userInfo) {
		 * common.addLocalJsonData("userInfo", userInfo); }); $state.go("test"); }
		 * else { console.log(res); } });
		 */
	};
}

var app = angular.module('ipadPos');

app.controller('userController', userController);
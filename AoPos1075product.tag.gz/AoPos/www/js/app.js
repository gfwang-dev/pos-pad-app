'use strict';
// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving
// Angular modules
// 'starter' is the name of this angular module example (also set in a <body>
// attribute in index.html)
// the 2nd parameter is an array of 'requires'
angular.module('ipadPos', [ 'ionic', 'tabSlideBox', 'ngCordova', 'ipadPos.common', 'ipadPos.db', 'ipadPos.config', 'ui.router', 'oc.lazyLoad', ]).constant('$ionicLoadingConfig', {
	template : '<i class="fa fa-spinner fa-pulse fa-3x fa-fw margin-bottom"></i>'
}).run(function($ionicSideMenuDelegate, $ionicPlatform, $state, $location, $rootScope, $http, common, db, $ionicLoading, $ionicPopup, $ionicHistory, $cordovaToast, $cordovaSQLite) {
	// 双击退出
	$ionicPlatform.registerBackButtonAction(function(e) {
		// 判断处于哪个页面时双击退出
		if ($location.path() == '/menu'||$location.path() == '/welcome') {
			if ($rootScope.backButtonPressedOnceToExit) {
				ionic.Platform.exitApp();
			} else {
				$rootScope.backButtonPressedOnceToExit = true;
				// $cordovaToast.showShortCenter('On a single exit system');
				setTimeout(function() {
					$rootScope.backButtonPressedOnceToExit = false;
				}, 2000);
			}
		}

		e.preventDefault();
		return false;
	}, 101);

	$ionicPlatform.ready(function() {
		// 创建sqlite
		if (window.cordova && window.cordova.plugins.Keyboard) {
			cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
		}
		if (window.cordova && window.cordova.plugins.Keyboard) {
		      window.cordova.plugins.Keyboard.hideKeyboardAccessoryBar(false);
		      if (window.ionic.Platform.isIOS()) {
		        window.cordova.plugins.Keyboard.disableScroll(true);
		      }
		 }
		if (window.StatusBar) {
			StatusBar.styleDefault();
		}
		// db.initDb();
		
		
		// console.log(u);
	});

}).config(function($httpProvider) {
	$httpProvider.interceptors.push(function($rootScope, $q) {
		return {
			request : function(config) {
				config.timeout = 10000;
				return config;
			},
			responseError : function(rejection) {
				switch (rejection.status) {
				case 408:
					console.log('connection timed out');
					break;
				}
				return $q.reject(rejection);
			}
		}
	})
}).config(function($ionicConfigProvider, $httpProvider) {
	$ionicConfigProvider.views.maxCache(0);
	$ionicConfigProvider.views.swipeBackEnabled(false);
	$ionicConfigProvider.platform.ios.tabs.style('standard');
	$ionicConfigProvider.platform.ios.tabs.position('bottom');
	$ionicConfigProvider.platform.android.tabs.style('standard');
	$ionicConfigProvider.platform.android.tabs.position('bottom');
	$ionicConfigProvider.platform.ios.navBar.alignTitle('center');
	$ionicConfigProvider.platform.android.navBar.alignTitle('center');
	$ionicConfigProvider.platform.ios.backButton.previousTitleText('').icon('ion-ios-arrow-thin-left');
	$ionicConfigProvider.platform.android.backButton.previousTitleText('').icon('ion-android-arrow-back');
	$ionicConfigProvider.platform.ios.views.transition('ios');
	$ionicConfigProvider.platform.android.views.transition('android');
	$ionicConfigProvider.scrolling.jsScrolling(true);
}).config(function($stateProvider, $urlRouterProvider) {

	// Ionic uses AngularUI Router which uses the concept of states
	// Learn more here: https://github.com/angular-ui/ui-router
	// Set up the various states which the app can be in.
	// Each state's controller can be found in controllers.js

	// Each tab has its own nav history stack:

	$stateProvider.state('pos', {
		abstract : true,
		template : '<div ui-view></div>',
		controller : function($scope, common,dbService,syndataService,$state) {
			var setting = {};
			var setting = common.getLocalJsonData("setting");
			if (!setting || setting == "null"||!setting.ip) {
				$state.go("welcome");
			}
		},
		resolve : {
			deps : [ '$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load([ {
					insertBefore : '#load_styles_before',
					files : [

					]
				}, {
					files : [ './js/services/syndata.svr.js', './js/services/dbService.svr.js' ]
				} ]).then(function() {
					return $ocLazyLoad.load([ './js/controllers/test.ctrl.js' ]);
				});
			} ]
		},
		cache : 'false'
	}).state('test', {
		url : '/test',
		templateUrl : 'templates/test.html',
		resolve : {
			deps : [ '$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load([ {
					insertBefore : '#load_styles_before',
					files : [

					]
				}, {
					files : [ './js/services/syndata.svr.js', './js/services/dbService.svr.js' ]
				} ]).then(function() {
					return $ocLazyLoad.load([ './js/controllers/test.ctrl.js' ]);
				});
			} ]
		},
		cache : 'false'
	})
	.state('pos.my-menu', {
		url : '/my-menu',
		templateUrl : 'templates/my-menu.html',
		cache : false,
		resolve : {
			deps : [ '$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load([ {
					insertBefore : '#load_styles_before',
					files : [

					]
				}, {
					files : [ './js/services/counter.svr.js','./js/services/deskService.svr.js','./js/services/dbService.svr.js', './js/services/syndata.svr.js', 
						'./js/common/config.js','./js/common/common.js']
				} ]).then(function() {
					return $ocLazyLoad.load([ './js/controllers/myMenu.ctrl.js' ]);
				});
			} ]
		}
	})
		
	.state('pos.counter', {
		url : '/counter',
		templateUrl : 'templates/counter.html',
		cache : false,
		resolve : {
			deps : [ '$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load([ {
					insertBefore : '#load_styles_before',
					files : [

					]
				}, {
					files : [ './js/services/counter.svr.js','./js/services/deskService.svr.js','./js/services/dbService.svr.js', './js/services/syndata.svr.js']
				} ]).then(function() {
					return $ocLazyLoad.load([ './js/controllers/counter.ctrl.js' ]);
				});
			} ]
		}
	})
	.state('pos.menu', {
		url : '/menu',
		templateUrl : 'templates/menu.html',
		cache : false,
		resolve : {
			deps : [ '$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load([ {
					insertBefore : '#load_styles_before',
					files : [

					]
				}, {
					files : [ './js/services/syndata.svr.js', './js/services/dbService.svr.js','./js/services/goods.svr.js' ]
				} ]).then(function() {
					return $ocLazyLoad.load([ './js/controllers/menu.ctrl.js' ]);
				});
			} ]
		}
	}).state('setting', {
		url : '/pop-setting',
		templateUrl : 'templates/pop/setting.html',
		cache : false,
		resolve : {
			deps : [ '$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load([ {
					insertBefore : '#load_styles_before',
					files : [

					]
				}, {
					files : [ './js/services/syndata.svr.js', './js/services/dbService.svr.js' ]
				} ]).then(function() {
					return $ocLazyLoad.load([ './js/controllers/test.ctrl.js' ]);
				});
			} ]
		}
	}).state('waiter-ctr', {
		url : '/waiter-ctr',
		templateUrl : 'templates/pop/waiter-ctr.html',
		cache : false,
		resolve : {
			deps : [ '$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load([ {
					insertBefore : '#load_styles_before',
					files : [

					]
				}, {
					files : [ './js/services/syndata.svr.js', './js/services/dbService.svr.js' ]
				} ]).then(function() {
					return $ocLazyLoad.load([ './js/controllers/test.ctrl.js' ]);
				});
			} ]
		}
	}).state('login', {
		url : '/login',
		templateUrl : 'templates/login.html',
		cache : 'false',
		resolve : {
			deps : [ '$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load([ {
					insertBefore : '#load_styles_before',
					files : [

					]
				}, {
					files : [ './js/services/user.svr.js' ]
				} ]).then(function() {
					return $ocLazyLoad.load([ './js/controllers/user.ctrl.js' ]);
				});
			} ]
		},
	}).state('welcome', {
		url:'/welcome',
		templateUrl : 'templates/welcome.html',
		controller : function($scope, common,dbService,syndataService,$state,$ionicLoading,db,$ionicPopup) {
			var setting = {};
			common.addLocalJsonData("currentDesk","");
			try{
			var setting = common.getLocalJsonData("setting");
			if (!setting || setting == "null"||!setting.ip) {
				// setTimeout(function(){
				db.initDb(function(){
					db.initSetting(function(){
				    	common.setIp ($scope,dbService,syndataService,function(){
							$ionicLoading.show({"template":"init data.."});
							syndataService.synData(function(){
								$ionicLoading.hide();
								$state.go("pos.menu");
							});
							
						});
				    });
				});
				    
				// }, 1000);
			}
			}catch(e){
				alert("获取设置异常"+e.message);
			}
		},
		resolve : {
			deps : [ '$ocLazyLoad', function($ocLazyLoad) {
				return $ocLazyLoad.load([ {
					insertBefore : '#load_styles_before',
					files : [

					]
				}, {
					files : [ './js/services/syndata.svr.js', './js/services/dbService.svr.js' ]
				} ]).then(function() {
					return $ocLazyLoad.load([ './js/controllers/test.ctrl.js' ]);
				});
			} ]
		},
		cache : 'false'
	});

	 // var ip = localStorage.getItem("ip");
	// if (!ip || ip == "null") {
		 $urlRouterProvider.otherwise('/welcome');
	 // } else {
		// $urlRouterProvider.otherwise('/menu');
	// }

}).config([ '$ocLazyLoadProvider', function($ocLazyLoadProvider) {
	$ocLazyLoadProvider.config({
		debug : false,
		events : false
	});
} ]);